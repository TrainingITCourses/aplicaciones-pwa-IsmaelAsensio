export interface Payload {
  id: number;
  name: string;
}
