export interface Status {
  id: number;
  name: string;
  description?: string;
  changed?: string;
  color?: string;
  icon?: string
}
