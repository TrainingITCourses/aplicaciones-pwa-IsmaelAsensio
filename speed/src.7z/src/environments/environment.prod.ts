export const environment = {
  production: true,
  apiUrl: 'http://api-base.escuelabinaria.com/api/'
};
